export type TGeneralPromotion = {
    id: number;
    title: string;
    sub: string;
    img: string;
  };
  