export type TBrand = {
    id: number;
    content: string;
    img: string;
  };
  