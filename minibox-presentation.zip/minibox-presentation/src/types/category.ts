export type TCategory = {
  id: number;
  title: string;
  img: string;
};
