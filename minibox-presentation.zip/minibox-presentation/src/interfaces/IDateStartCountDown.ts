export interface IDateStartCountDown{
    years: number,
    month:number,
    days: number,
    hours: number,
    minutes: number,
    seconds: number,
    miliseconds: number,
}