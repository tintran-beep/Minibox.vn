import cate1 from "@assets/images/cate1.jpg";
import cate2 from "@assets/images/cate2.jpg";
import cate3 from "@assets/images/cate3.jpg";
import cate4 from "@assets/images/cate4.jpg";
import cate5 from "@assets/images/cate5.jpg";
import cate6 from "@assets/images/cate6.jpg";
import bgHeading from "@assets/images/bg-heading.jpg";
import prBanner1 from "@assets/images/promote-banner-1.jpg";
import prBanner2 from "@assets/images/promote-banner-2.jpg";
import prBanner3 from "@assets/images/promote-banner-3.jpg";
import prd1 from "@assets/images/prd1.jpg";
import prd2 from "@assets/images/prd2.jpg";
import prd3 from "@assets/images/prd3.jpg";
import prd4 from "@assets/images/prd4.jpg";
import prd5 from "@assets/images/prd5.jpg";
import prd6 from "@assets/images/prd6.jpg";
import prd7 from "@assets/images/prd7.jpg";
import prd8 from "@assets/images/prd8.jpg";
import prd1_1 from "@assets/images/prd1-1.jpg";
import prd2_1 from "@assets/images/prd2-1.jpg";
import prd3_1 from "@assets/images/prd3-1.jpg";
import prd4_1 from "@assets/images/prd4-1.jpg";
import prd5_1 from "@assets/images/prd5-1.jpg";
import prd6_1 from "@assets/images/prd6-1.jpg";
import prd7_1 from "@assets/images/prd7-1.jpg";
import prd8_1 from "@assets/images/prd8-1.jpg";
import dailyPr from "@assets/images/dailyPr.jpg";
import brn1 from "@assets/images/brn1.png";
import brn2 from "@assets/images/brn2.png";
import brn3 from "@assets/images/brn3.png";
import brn4 from "@assets/images/brn4.png";
import brn5 from "@assets/images/brn5.png";
import brn6 from "@assets/images/brn6.png";

export {
  cate1,
  cate2,
  cate3,
  cate4,
  cate5,
  cate6,
  bgHeading,
  prBanner1,
  prBanner2,
  prBanner3,
  prd1,
  prd2,
  prd3,
  prd4,
  prd5,
  prd6,
  prd7,
  prd8,
  prd1_1,
  prd2_1,
  prd3_1,
  prd4_1,
  prd5_1,
  prd6_1,
  prd7_1,
  prd8_1,
  dailyPr,
  brn1,
  brn2,
  brn3,
  brn4,
  brn5,
  brn6,
};
