
const Categories = () => {
  return (
    <div className="flex gap-3"></div>
  );
};

export default Categories;
